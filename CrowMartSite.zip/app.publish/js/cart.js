window.onload = function () {
    LoadCart();
};

function LoadCart() {
    var itemsInCart = GetCart();

    var totalPrice = 0;
    var itemsCount = itemsInCart.length;

    itemsInCart.forEach(function (item) {
        var price = parseInt(item.price, 10);
        totalPrice += price;

    });

    if (document.getElementById("count")) {
        document.getElementById("count").innerHTML = `You have ${itemsCount} items in cart`;
        document.getElementById("total").innerHTML = `Total: $${totalPrice}`;
    };
};

function AddBtn(e) {
    var name = e.parentElement.getElementsByTagName("h4")[0].innerHTML;
    var dataID = e.parentElement.getAttribute('data-item-id');
    var price = e.parentElement.getElementsByTagName("h5")[0].innerHTML.replace('$', '');

    SaveCart(dataID, price);
    LoadCart();
    alert(`${name} added.`);
};

function GetCart()
{
    if (sessionStorage.getItem("crowCart")) {
        json = sessionStorage.getItem("crowCart");
        return JSON.parse(json);
    }
    return [];
}

function SaveCart(dataID, price)
{
    var itemsInCart = [];

    if (sessionStorage.getItem("crowCart")) {
        json = sessionStorage.getItem("crowCart");
        itemsInCart = JSON.parse(json);
        sessionStorage.removeItem("crowCart");
    }

    itemsInCart.push({ "id": dataID, "price": price });
    sessionStorage.setItem("crowCart", JSON.stringify(itemsInCart));
}