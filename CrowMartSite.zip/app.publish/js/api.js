var site_name = 'BLACKCROW';
var page_id;
var visitor_id = "asdf";
var cart = GetCart();

var baseUrl = 'https://api.sandbox.blackcrow.ai';

document.addEventListener("DOMContentLoaded", () => {
    if (window.location.pathname.split("/").pop() == "index.html") {
        page_id = "home";
    } else
    {
        page_id = "other";
    }
    SendResquest();
});

function GetCart() {
    if (sessionStorage.getItem("crowCart")) {
        json = sessionStorage.getItem("crowCart");
        return JSON.parse(json);
    }
    return [];
}

function SendResquest()
{
    var data = {
        site_name: site_name,
        page_id: page_id,
        visitor_id: visitor_id,
        cart: cart
    }

    const Http = new XMLHttpRequest();
    const url = baseUrl + '/v1/events/view';
    Http.open("POST", url);
    Http.send(JSON.stringify(data));

    Http.onreadystatechange = (e) => {
        console.log(Http.responseText)
    }
}